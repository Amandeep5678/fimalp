package com.example.finalproject;

import android.os.Parcel;
import android.os.Parcelable;

public class Beer  implements Parcelable{


    private String name;
    private String image_url;
    private double abv;
    private double ph ;
    private int ibu;
    public String tagline;
    private String description;



    public Beer(double abv, double ph, int ibu, String description, String name, String image_url, String tagline) {
        this.abv = abv;
        this.ph = ph;
        this.ibu = ibu;
        this.description = description;
        this.tagline=tagline;
        this.name= name;
        this.image_url = image_url;
    }
  protected Beer(Parcel in){
        name= in .readString();
        image_url= in.readString();
        description=in.readString();
        abv=in.readDouble();
        tagline=in.readString();
        ph=in.readDouble();
        ibu=in.readInt();

  }
  public static final Parcelable.Creator<Beer> CREATOR=new Creator<Beer>() {
      @Override
      public Beer createFromParcel(Parcel in) {
          return new Beer(in);
      }

      @Override
      public Beer[] newArray(int size) {
          return new Beer[size];
      }
  };

    public Beer(String name, String image_url, double abv, double ph, int ibu, String description, String tagline) {
    }

    public String getName() {
        return name;
    }

    public void setName(String Name) {
        this.name = name;
    }

    public String getImage() {
        return image_url;
    }

    public void setImage(String image) {
        this.image_url = image_url;
    }

    public double getAbv() {
        return abv;
    }

    public void setAbv(double abv) {
        this.abv = abv;
    }
    public String getTag() {
        return tagline;
    }

    public void setTag(String tag) {
        this.tagline = tagline;
    }

    public double getPh() {
        return ph;
    }

    public void setPh(double ph) {
        this.ph = ph;
    }

    public int getIbu() {
        return ibu;
    }

    public void setIbu(int ibu) {
        this.ibu = ibu;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

  public int describeContents(){
        return 0;
  }

 public void writeToParcel(Parcel dest,int flags){
        dest.writeString(name);
     dest.writeString(image_url);
     dest.writeInt(ibu);
     dest.writeDouble(ph);
     dest.writeDouble(abv);
     dest.writeString(tagline);
     dest.writeString(description);
 }


}
