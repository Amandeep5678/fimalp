package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.icu.text.Transliterator;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {
    ListView lisv;
    ListAdapter listAdapter;
    ArrayList<Beer> bArraylist;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lisv = findViewById(R.id.ListView);
        bArraylist= new ArrayList<Beer>();

        String beerurl = getResources().getString(R.string.beerurl);
        bArraylist= getData(beerurl);
        listAdapter = new ListAdapter(MainActivity.this, getData(beerurl));

        lisv.setAdapter(listAdapter);
        lisv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getApplicationContext(), bArraylist.get(position).getName(), Toast.LENGTH_LONG).show();
                Intent i = new Intent(MainActivity.this, BeerDetail.class);
               i.putExtra("Beer",bArraylist.get(position));
               startActivity(i);
            }
        });

    }
    public ArrayList<Beer> getData(String url){
        ArrayList<Beer> beerArrayList= new ArrayList<>();
        try {
            String jsondata = new  Async().execute(url).get();
               JSONObject mainobject= new JSONObject(jsondata);

            JSONArray beerArray=  mainobject.getJSONArray("Beer");
            int ibu;
            double ph,abv;
            String name,image_url,tagline,description;

            for(int i=0; i<beerArray.length();i++){
                JSONObject childobj = beerArray.getJSONObject(i);
                 name =childobj.getString("name");
                 image_url = childobj.getString("image_url") ;
                  abv=childobj.getDouble("abv");
                  ph= childobj.getDouble("ph") ;
                  ibu=childobj.getInt("ibu");
                 tagline =childobj.getString("tagline");
                 description=childobj.getString("description");
                beerArrayList.add (new Beer(name,image_url,abv,ph,ibu,description,tagline));
                System.out.println("Size of Arraylist:"+beerArrayList.size());
            }
        }
        catch (InterruptedException e){
            e.printStackTrace();
        }
        catch (ExecutionException e){
            e.printStackTrace();
        }
        catch (JSONException e){
            e.printStackTrace();
        }
        System.out.println("Size of arraylist(Outside try):"+beerArrayList.size());
        return  beerArrayList;
    }
}